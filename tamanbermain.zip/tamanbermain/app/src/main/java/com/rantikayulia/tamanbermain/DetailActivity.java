package com.rantikayulia.tamanbermain;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {

    public static final String airace = "AIRACE";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        TextView airaceRecived = findViewById(R.id.airace);
        ImageView imageView = findViewById(R.id.iv_bg);

        String nama = getIntent().getStringExtra(String.valueOf(airace));
        int Photo = getIntent().getIntExtra("coba",0);
        airaceRecived.setText(nama);

        Glide.with(this)
                .load(Photo)
                .into(imageView);

        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle("Detail");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }
    public void displayToast(String message) {
        Toast.makeText(getApplicationContext(), message,
                Toast.LENGTH_SHORT).show();
    }

    public void openOrket(View view) {
        displayToast("Kamu telah memesan tiket!");
    }
    
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    public void onBackPressed(){

        super.onBackPressed();
    }



}