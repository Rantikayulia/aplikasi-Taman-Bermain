package com.rantikayulia.tamanbermain;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class WahanaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wahana);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle("Wahana");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        RecyclerView recyclerView = findViewById(R.id.rv_tamanbermain);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        WahanaData[] wahanaData = new  WahanaData[]{
                new WahanaData("Air Race",R.drawable.airace),
                new WahanaData("Adrenaline Coaster",R.drawable.rolcost),
                new WahanaData("Bianglala",R.drawable.tipsbiang),
                new WahanaData("Komedi Putar",R.drawable.koptar),
                new WahanaData("Giant Swing",R.drawable.gintswing),
                new WahanaData("Istana Bola",R.drawable.isbol),
        };
        WahanaAdapter wahanaAdapter = new WahanaAdapter(wahanaData,WahanaActivity.this);
        recyclerView.setAdapter(wahanaAdapter);

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    public void onBackPressed(){

        super.onBackPressed();
    }
}