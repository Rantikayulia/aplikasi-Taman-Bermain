package com.rantikayulia.tamanbermain;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class WahanaAdapter extends RecyclerView.Adapter<WahanaAdapter.ViewHolder>{

    WahanaData[] wahanaData;
    Context context;
    public WahanaAdapter(WahanaData[] wahanaData, WahanaActivity activity ) {
    this.wahanaData = wahanaData;
    this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.wahanalist,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final WahanaData wahanaDataList = wahanaData[position];
        holder.textViewNama.setText(wahanaDataList.getNamaWahana());
        holder.wahanaimage.setImageResource(wahanaDataList.getWahanaImage());

       String nama = wahanaDataList.getNamaWahana();
       int photo = wahanaDataList.getWahanaImage();

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
 //              Toast.makeText(context, wahanaDataList.getNamaWahana(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra(DetailActivity.airace,nama);
                intent.putExtra("coba",photo);
                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return wahanaData.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView wahanaimage;
        TextView textViewNama;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            wahanaimage = itemView.findViewById(R.id.imageViewwahana);
            textViewNama = itemView.findViewById(R.id.textViewwahana);
        }
    }

}
