package com.rantikayulia.tamanbermain;

public class WahanaData {

    private String namaWahana;
    private Integer wahanaImage;

    public WahanaData(String namaWahana, Integer wahanaImage) {
        this.namaWahana = namaWahana;
        this.wahanaImage = wahanaImage;
    }

    public String getNamaWahana() {
        return namaWahana;
    }

    public void setNamaWahana(String namaWahana) {
        this.namaWahana = namaWahana;
    }

    public Integer getWahanaImage() {
        return wahanaImage;
    }

    public void setWahanaImage(Integer wahanaImage) {
        this.wahanaImage = wahanaImage;
    }
}
